import boto3

ec2 = boto3.client('ec2')

def lambda_handler(event, context):
    try:
        instance_id = event['detail']['responseElements']['instancesSet']['items'][0]['instanceId']
        print(f"New instance launched: {instance_id}")

        # Describe the instance to fetch tags
        reservations = ec2.describe_instances(InstanceIds=[instance_id])['Reservations']
        tags = reservations[0]['Instances'][0].get('Tags', [])

        required_tag = "Environment"

        if not any(tag["Key"] == required_tag for tag in tags):
            print(f"Instance {instance_id} missing tag '{required_tag}'. Stopping it...")
            ec2.stop_instances(InstanceIds=[instance_id])
        else:
            print(f"Instance {instance_id} has required tags. No action taken.")

    except Exception as e:
        print(f"Error: {str(e)}")

